# Event Types

This page serves as a detailed reference to all the event types `SpessaSynthProcessor` emits.

## Table summary

| Name                 | Description                                     |
| -------------------- | ----------------------------------------------- |
| `noteOn`             | Key has been pressed.                           |
| `noteOff`            | Key has been released.                          |
| `controllerChange`   | Controller has been changed.                    |
| `programChange`      | Program has been changed.                       |
| `channelPressure`    | Channel's pressure has been changed.            |
| `polyPressure`       | Note's pressure has been changed.               |
| `stopAll`            | All voices were stopped on a given channel.     |
| `channelAdded`       | A new channel was added to the synth.           |
| `presetListChange`   | The preset list has been changed/initialized.   |
| `reset`              | The synthesizer has been reset.                 |
| `displayMessage`     | The synthesizer has received a display message. |
| `globalParamChange`  | A global MIDI Parameter has been changed.       |
| `channelParamChange` | A channel MIDI Parameter has been changed.      |
| `effectChange`       | An effect parameter has been changed.           |

!!! Note

    `presetListChange` is the recommended way of retrieving the preset list.
    It automatically combines the sound banks and sends the list of presets as they will be played.
    It also signals that the sound bank has been fully loaded.

## Detailed descriptions

### `noteOn`

This event is triggered when a note is pressed on any channel.

- `midiNote`: `number` - the MIDI key number of the note that was pressed. Ranges from 0 to 127.
- `channel`: `number` - the channel that the note was played on. Usually it ranges from 0 to 16, but it depends on the
  channel count.
- `velocity`: `number` - the velocity of the note (usually more means louder). Ranges from 0 to 127.

!!! Note

    The note events report the direct MIDI note number requested. For the internal note, you can apply the key shift:
    ```ts
    const actualNote =
        event.midiNote +
        Math.trunc(this.synth.systemParameters.pitchOffset) +
        this.synth.midiParameters.masterKeyShift +
        this.synth.midiChannels[event.channel].systemParameters.pitchOffset +
        this.synth.midiChannels[event.channel].midiParameters.keyShift;
    ```

### `noteOff`

This event is triggered when a note is released on any channel.

- `midiNote`: `number` - the MIDI key number of the note that was released. Ranges from 0 to 127.
- `channel`: `number` - the channel number which got the note released. Usually it ranges from 0 to 16, but it depends
  on the channel count.

### `controllerChange`

This event is triggered when a controller is changed on any channel (usually MIDI program change,
though [Some system exclusives can change it too](../extra/midi-implementation.md)).

- `channel`: `number` - the channel that CC was changed on. Usually it ranges from 0 to 16, but it depends on the
  channel count.
- `controller`: `number` - the number of the MIDI controller list. Ranges from 0 to 127.
- `value`: `number` - the new value of the controller. Ranges from 0 to 127.

Note that this event is also called after `reset` if there were any locked controllers.
For example, if CC#1 was locked to 64,
after `reset` a `controllerChange` event will be called with `controller` 1 and `value` 64.

### `programChange`

This event is triggered when a program is changed on any channel (usually MIDI program change,
though [Some system exclusives can change it too](../extra/midi-implementation.md)).
It is also called when receiving a system reset message.

- `channel`: `number` - the channel that had its program changed. Usually it ranges from 0 to 16, but it depends on the
  channel count.
- `name`: `string` - The name of the preset.
- `isDrum`: `boolean` - if this preset is a drum preset.
- `program`: `number` - the new MIDI program number. Ranges from 0 to 127.
- `bankMSB`: `number` - the new bank MSB number of the preset. Ranges from 0 to 127.
- `bankLSB`: `number` - the new bank LSB number of the preset. Ranges from 0 to 127.
- `isGMGSDrum`: `boolean` - if the new preset is a GM or GS drum preset. **This does not determine whether this preset is actually a drum preset.**

!!! Warning

    `isDrum` is the correct way of distinguishing between drum and melodic presets.

    _Do not_ use `isGMGSDrum` as the indication!

Note: the last 4 properties are a [MIDI Patch](midi-patch.md) - a way of identifying the selected preset from the preset list if needed.
Simply perform a `.find()` call and compare these properties to find the exact preset in the preset list.

!!! Tip

    This event can be used as a replacement for the previous `drumChange` event as it contains the `isDrum` property and always has been called when `drumChange` happened.

### `polyPressure`

This event is triggered when a MIDI polyphonic pressure event is received. This controls the pressure of a single note.
By default, this controls vibrato in SpessaSynth, though it can be changed with sound bank modulators.

- `midiNote`: `number` - the MIDI key number of the note that was affected. Ranges from 0 to 127.
- `channel`: `number` - the channel affected. Usually it ranges from 0 to 16, but it depends on the channel count.
- `pressure`: `number` - the new pressure. Ranges from 0 to 127.

### `stopAll`

This event is triggered when all voices are stopped. Either manually or when receiving a system reset.

- `channel`: `number` - the MIDI channel number.
- `force`: `boolean` - if the channel was force stopped. (no release time)

### `channelAdded`

This event is triggered when a new channel is added to the synthesizer.
Either manually,
or when the sequencer detects
a [Multi-Port MIDI file.](../extra/about-multi-port.md)

This event has no data.

### `presetListChange`

This event is triggered when the preset list has been changed or initialized,
by adding, removing or changing sound banks, or when a MIDI with an embedded sound bank is loaded.
Note that this is the recommended way of retrieving the preset list, rather than loading the sound bank manually.

The event data is the preset list. Each item is a preset list entry:

- The properties of a [MIDI Patch](midi-patch.md).
- `name`: `string` - The name of the preset.
- `isDrum`: `boolean` - if this preset is a drum preset.

!!! Warning

    `isDrum` is the correct way of distinguishing between drum and melodic presets.

    _Do not_ use `isGMGSDrum` as the indication!

### `reset`

This event is triggered when all controllers and programs have been reset. Effectively a system reset.

The data is the new `MIDISystem`. Either `gs`, `gm`, `gm2` or `xg`.

!!! Note

    If there were any locked controllers, they will be restored via `controllerChange` event after (like
    described in `controllerChange`).

### `displayMessage`

This event is triggered when a SysEx to display some text has been received.

The data is a number array of the entire system exclusive, **excluding the `F0` status byte.**

Notable messages that can trigger this event:

- All messages with GS Model ID of `0x45` (Display Data)
- GS Patch Name
- GS Drum Map Name
- XG Display Letter
- XG Display Bitmap

### `globalParamChange`

This event is triggered when a [Global MIDI Parameter](global-parameters.md#midi) changes.

- `parameter`: `GlobalMIDIParameter` - the parameter type (string)
- `value`: varies - the new value of this parameter.

### `channelParamChange`

This event is triggered when a [Channel MIDI Parameter](midi-channel/channel-parameters.md#midi) changes.

- `parameter`: `ChannelMIDIParameter` - the parameter type (string)
- `value`: varies - the new value of this parameter.

### `effectChange`

This event is triggered when an effect processor has one of its parameters changed.

- `effect`: `"reverb"|"chorus"|"delay"|"insertion"` - The effect processor that triggered the event.
- `parameter`: varies - The parameter corresponding to the effect processor or `"macro"` if a preset macro was set.
- `value`: `number` - The new 7-bit value of the parameter.

The effects and their parameters can be found here:

- [Reverb](effects/reverb-processor.md)
- [Chorus](effects/chorus-processor.md)
- [Delay](effects/delay-processor.md)

#### Insertion

The parameters behave a bit differently when the `effect` is set to `"insertion"`:

- `parameter`: `number`

The parameter that was changed. This maps to GS address map at addr2 = 0x03.
See SC-8850 Manual p.237,
for example:

- `0x0` - EFX type, the value is 16 bit in this special case. Note that this resets the parameters!
- `0x3` - EFX param 1
- `0x16` - EFX param 20 (usually level)
- `0x17` - EFX send to reverb
  For these, the value is a 7-bit number set via the system exclusive.

There are two exceptions:

- `-1` - the channel has ENABLED the effect.
- `-2` - the channel has DISABLED the effect.
  For both of these cases, `value` is the channel number.

`value`: `number` - the new value for the given parameter.
