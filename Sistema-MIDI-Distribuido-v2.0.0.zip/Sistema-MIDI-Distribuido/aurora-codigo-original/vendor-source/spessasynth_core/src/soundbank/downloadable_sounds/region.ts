import { DownloadableSoundsArticulation } from "./articulation";
import type { GenericRange } from "../types";
import { WaveSample } from "./wave_sample";
import { WaveLink } from "./wave_link";
import { RIFFChunk } from "../../utils/riff_chunk";
import {
    readLittleEndianIndexed,
    writeWord
} from "../../utils/byte_functions/little_endian";
import { DLSVerifier } from "./dls_verifier";
import type { DownloadableSoundsSample } from "./sample";
import { IndexedByteArray } from "../../utils/indexed_array";
import type { BasicInstrumentZone } from "../basic_soundbank/basic_instrument_zone";
import type { BasicSample } from "../basic_soundbank/basic_sample";
import type { BasicInstrument } from "../basic_soundbank/basic_instrument";
import {
    GeneratorLimits,
    GeneratorTypes
} from "../basic_soundbank/generator_types";
import { SpessaLog } from "../../utils/loggin";

export class DownloadableSoundsRegion extends DLSVerifier {
    public readonly articulation = new DownloadableSoundsArticulation();
    /**
     * Specifies the key range for this region.
     */
    public keyRange: GenericRange = {
        min: 0,
        max: 127
    };
    /**
     * Specifies the velocity range for this region.
     */
    public velRange: GenericRange = {
        min: 0,
        max: 127
    };

    /**
     * Specifies the key group for a drum instrument. Key group values allow multiple regions
     * within a drum instrument to belong to the same "key group." If a synthesis engine is
     * instructed to play a note with a key group setting and any other notes are currently playing
     * with this same key group, then the synthesis engine should turn off all notes with the same
     * key group value as soon as possible.
     */
    public keyGroup = 0;

    /**
     * Specifies flag options for the synthesis of this region.
     */
    public fusOptions = 0;

    /**
     * Indicates the layer of this region for editing purposes. This field facilitates the
     * organization of overlapping regions into layers for display to the user of a DLS sound editor.
     * For example, if a piano sound and a string section are overlapped to create a piano/string pad,
     * all the regions of the piano might be labeled as layer 1, and all the regions of the string
     * section might be labeled as layer 2
     */
    public usLayer = 0;

    public readonly waveSample: WaveSample;
    public readonly waveLink: WaveLink;

    public constructor(waveLink: WaveLink, waveSample: WaveSample) {
        super();
        this.waveSample = waveSample;
        this.waveLink = waveLink;
    }

    public static copyFrom(inputRegion: DownloadableSoundsRegion) {
        const outputRegion = new DownloadableSoundsRegion(
            WaveLink.copyFrom(inputRegion.waveLink),
            WaveSample.copyFrom(inputRegion.waveSample)
        );
        outputRegion.keyGroup = inputRegion.keyGroup;
        outputRegion.keyRange = { ...inputRegion.keyRange };
        outputRegion.velRange = { ...inputRegion.velRange };
        outputRegion.usLayer = inputRegion.usLayer;
        outputRegion.fusOptions = inputRegion.fusOptions;
        outputRegion.articulation.copyFrom(inputRegion.articulation);
        return outputRegion;
    }

    public static read(samples: DownloadableSoundsSample[], chunk: RIFFChunk) {
        const regionChunks = this.verifyAndReadList(chunk, "rgn ", "rgn2");
        // Wsmp: wave sample chunk
        const waveSampleChunk = regionChunks.find((c) => c.header === "wsmp");
        let waveSample = waveSampleChunk
            ? WaveSample.read(waveSampleChunk)
            : undefined;

        // Wlnk: wave link chunk
        const waveLinkChunk = regionChunks.find((c) => c.header === "wlnk");
        if (!waveLinkChunk) {
            // No wave link means no sample. What? Why is it even here then?
            SpessaLog.warn(
                "Invalid DLS region: missing 'wlnk' chunk! Discarding..."
            );
            return;
        }
        const waveLink = WaveLink.read(waveLinkChunk);

        // Region header
        const regionHeader = regionChunks.find((c) => c.header === "rgnh");
        if (!regionHeader) {
            SpessaLog.warn(
                "Invalid DLS region: missing 'rgnh' chunk! Discarding..."
            );
            return;
        }

        const sample = samples[waveLink.tableIndex];
        if (!sample) {
            DownloadableSoundsRegion.parsingError(
                `Invalid sample index: ${waveLink.tableIndex}. Samples available: ${samples.length}`
            );
        }
        waveSample ??= sample.waveSample;

        const region = new DownloadableSoundsRegion(waveLink, waveSample);

        // Key range
        const keyMin = readLittleEndianIndexed(regionHeader.data, 2);
        const keyMax = readLittleEndianIndexed(regionHeader.data, 2);
        // Vel range
        let velMin = readLittleEndianIndexed(regionHeader.data, 2);
        let velMax = readLittleEndianIndexed(regionHeader.data, 2);

        // A fix for not cool files
        // Cannot do the same to key zones sadly
        if (velMin === 0 && velMax === 0) {
            velMax = 127;
            velMin = 0;
        }
        region.keyRange.max = keyMax;
        region.keyRange.min = keyMin;

        region.velRange.max = velMax;
        region.velRange.min = velMin;

        // FusOptions
        region.fusOptions = readLittleEndianIndexed(regionHeader.data, 2);
        // KeyGroup: essentially exclusive class
        region.keyGroup = readLittleEndianIndexed(regionHeader.data, 2);

        // UsLayer
        if (regionHeader.data.length - regionHeader.data.currentIndex >= 2) {
            region.usLayer = readLittleEndianIndexed(regionHeader.data, 2);
        }

        region.articulation.read(regionChunks);
        return region;
    }

    public static fromSFZone(
        zone: BasicInstrumentZone,
        samples: BasicSample[]
    ) {
        const waveSample = WaveSample.fromSFZone(zone);

        const waveLink = WaveLink.fromSFZone(samples, zone);

        const region = new DownloadableSoundsRegion(waveLink, waveSample);

        // Assign ranges
        region.keyRange.min = Math.max(zone.keyRange.min, 0);
        region.keyRange.max = zone.keyRange.max;
        region.velRange.min = Math.max(zone.velRange.min, 0);
        region.velRange.max = zone.velRange.max;

        // KeyGroup (exclusive class)
        region.keyGroup = zone.getGenerator(GeneratorTypes.exclusiveClass, 0);
        region.articulation.fromSFZone(zone);
        return region;
    }

    public write() {
        // In that order!
        const chunks = [
            this.writeHeader(),
            this.waveSample.write(),
            this.waveLink.write(),
            ...this.articulation.write()
        ];
        return RIFFChunk.getParts("rgn2", chunks, false, true);
    }

    public toSFZone(
        instrument: BasicInstrument,
        samples: BasicSample[]
    ): BasicInstrumentZone {
        const sample = samples[this.waveLink.tableIndex];
        if (!sample) {
            DownloadableSoundsRegion.parsingError(
                `Invalid sample index: ${this.waveLink.tableIndex}`
            );
        }
        const zone = instrument.createZone(sample);
        zone.keyRange = this.keyRange;
        zone.velRange = this.velRange;
        // If the zones are default (0-127), set to -1 as "not set"
        if (this.keyRange.max === 127 && this.keyRange.min === 0) {
            zone.keyRange.min = -1;
        }
        if (this.velRange.max === 127 && this.velRange.min === 0) {
            zone.velRange.min = -1;
        }

        // KeyGroup: essentially exclusive class
        if (this.keyGroup !== 0) {
            zone.setGenerator(GeneratorTypes.exclusiveClass, this.keyGroup);
        }

        this.waveSample.toSFZone(zone, sample);
        this.articulation.toSFZone(zone);
        // Remove generators with default values
        zone.generators = zone.generators.filter(
            (g) => g.value !== GeneratorLimits[g.type].def
        );
        return zone;
    }

    private writeHeader() {
        // Region header
        const rgnhData = new IndexedByteArray(14);
        // KeyRange
        writeWord(rgnhData, Math.max(this.keyRange.min, 0));
        writeWord(rgnhData, this.keyRange.max);
        // VelRange
        writeWord(rgnhData, Math.max(this.velRange.min, 0));
        writeWord(rgnhData, this.velRange.max);
        writeWord(rgnhData, this.fusOptions);
        // KeyGroup (exclusive class)
        writeWord(rgnhData, this.keyGroup);
        // UsLayer
        writeWord(rgnhData, this.usLayer);
        return RIFFChunk.write("rgnh", rgnhData);
    }
}
