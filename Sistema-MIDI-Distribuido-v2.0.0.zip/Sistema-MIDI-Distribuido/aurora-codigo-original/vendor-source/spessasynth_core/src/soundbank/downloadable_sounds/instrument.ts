import { DownloadableSoundsArticulation } from "./articulation";
import { DownloadableSoundsRegion } from "./region";
import { RIFFChunk } from "../../utils/riff_chunk";
import {
    getStringBytes,
    readBinaryStringIndexed
} from "../../utils/byte_functions/string";
import { SpessaLog } from "../../utils/loggin";
import {
    readLittleEndianIndexed,
    writeDword
} from "../../utils/byte_functions/little_endian";
import { ConsoleColors } from "../../utils/other";
import { DLSVerifier } from "./dls_verifier";
import type { DLSChunkFourCC } from "../types";
import type { DownloadableSoundsSample } from "./sample";
import { IndexedByteArray } from "../../utils/indexed_array";
import { BasicPreset } from "../basic_soundbank/basic_preset";
import { BasicInstrument } from "../basic_soundbank/basic_instrument";
import {
    BasicSample,
    BasicSoundBank,
    GeneratorLimits,
    GeneratorTypes,
    type MIDIPatch,
    Modulator
} from "../exports";
import {
    DEFAULT_DLS_CHORUS,
    DEFAULT_DLS_REVERB
} from "./default_dls_modulators";

/**
 * Represents a proper DLS instrument, with regions and articulation.
 * DLS
 */
export class DownloadableSoundsInstrument
    extends DLSVerifier
    implements MIDIPatch
{
    public readonly articulation = new DownloadableSoundsArticulation();
    public readonly regions = new Array<DownloadableSoundsRegion>();
    public name = "Unnamed";
    public bankLSB = 0;
    public bankMSB = 0;
    public isGMGSDrum = false;
    public program = 0;

    public static copyFrom(inputInstrument: DownloadableSoundsInstrument) {
        const outputInstrument = new DownloadableSoundsInstrument();
        outputInstrument.name = inputInstrument.name;
        outputInstrument.isGMGSDrum = inputInstrument.isGMGSDrum;
        outputInstrument.bankMSB = inputInstrument.bankMSB;
        outputInstrument.bankLSB = inputInstrument.bankLSB;
        outputInstrument.program = inputInstrument.program;
        outputInstrument.articulation.copyFrom(inputInstrument.articulation);
        for (const region of inputInstrument.regions) {
            outputInstrument.regions.push(
                DownloadableSoundsRegion.copyFrom(region)
            );
        }
        return outputInstrument;
    }

    public static read(samples: DownloadableSoundsSample[], chunk: RIFFChunk) {
        const chunks = this.verifyAndReadList(chunk, "ins ");

        const instrumentHeader = chunks.find((c) => c.header === "insh");
        if (!instrumentHeader) {
            SpessaLog.groupEnd();
            throw new Error("No instrument header!");
        }

        // Read the instrument name in INFO
        let instrumentName = ``;
        const infoChunk = RIFFChunk.findListType(chunks, "INFO");
        if (infoChunk) {
            let info = RIFFChunk.read(infoChunk.data);
            while (info.header !== "INAM") {
                info = RIFFChunk.read(infoChunk.data);
            }
            instrumentName = readBinaryStringIndexed(
                info.data,
                info.data.length
            ).trim();
        }
        if (instrumentName.length === 0) {
            instrumentName = `Unnamed Instrument`;
        }
        const instrument = new DownloadableSoundsInstrument();
        instrument.name = instrumentName;
        // Read instrument header
        const regions = readLittleEndianIndexed(instrumentHeader.data, 4);
        /**
         *
         * Specifies the MIDI bank location. Bits 0-6 are defined as MIDI CC32 and bits 8-14 are
         * defined as MIDI CC0. Bits 7 and 15-30 are reserved and should be written to zero. If the
         * F_INSTRUMENT_DRUMS flag (Bit 31) is equal to 1 then the instrument is a drum
         * instrument; if equal to 0 then the instrument is a melodic instrument.
         */
        const ulBank = readLittleEndianIndexed(instrumentHeader.data, 4);
        /**
         * Specifies the MIDI Program Change (PC) value. Bits 0-6 are defined as PC value and bits 7-
         * 31 are reserved and should be written to zero.
         */
        const ulInstrument = readLittleEndianIndexed(instrumentHeader.data, 4);

        instrument.program = ulInstrument & 127;
        instrument.bankMSB = (ulBank >>> 8) & 127;
        instrument.bankLSB = ulBank & 127;
        instrument.isGMGSDrum = ulBank >>> 31 > 0;

        SpessaLog.groupCollapsed(
            `%cParsing %c"${instrumentName}"%c...`,
            ConsoleColors.info,
            ConsoleColors.recognized,
            ConsoleColors.info
        );

        // List of regions
        const regionListChunk = RIFFChunk.findListType(chunks, "lrgn");
        if (!regionListChunk) {
            SpessaLog.groupEnd();
            throw new Error("No region list!");
        }

        instrument.articulation.read(chunks);

        // Read regions
        for (let i = 0; i < regions; i++) {
            const chunk = RIFFChunk.read(regionListChunk.data);
            this.verifyHeader(chunk, "LIST");
            const type = readBinaryStringIndexed(
                chunk.data,
                4
            ) as DLSChunkFourCC;
            if (type !== "rgn " && type !== "rgn2") {
                SpessaLog.groupEnd();
                this.parsingError(
                    `Invalid DLS region! Expected "rgn " or "rgn2" got "${type}"`
                );
            }

            const region = DownloadableSoundsRegion.read(samples, chunk);
            if (region) {
                instrument.regions.push(region);
            }
        }
        SpessaLog.groupEnd();
        return instrument;
    }

    public static fromSFPreset(preset: BasicPreset, samples: BasicSample[]) {
        const instrument = new DownloadableSoundsInstrument();
        instrument.name = preset.name;
        instrument.bankLSB = preset.bankLSB;
        instrument.bankMSB = preset.bankMSB;
        instrument.program = preset.program;
        instrument.isGMGSDrum = preset.isGMGSDrum;
        SpessaLog.group(
            `%cConverting %c${preset.toString()}%c to DLS...`,
            ConsoleColors.info,
            ConsoleColors.value,
            ConsoleColors.info
        );

        // Combine preset and instrument zones into a single instrument zone (region) list
        const inst = preset.toFlattenedInstrument();

        for (const z of inst.zones) {
            instrument.regions.push(
                DownloadableSoundsRegion.fromSFZone(z, samples)
            );
        }
        SpessaLog.groupEnd();
        return instrument;
    }

    public write() {
        SpessaLog.groupCollapsed(
            `%cWriting %c${this.name}%c...`,
            ConsoleColors.info,
            ConsoleColors.recognized,
            ConsoleColors.info
        );
        const chunks: Uint8Array[] = [this.writeHeader()];

        const regionChunks = this.regions.flatMap((r) => r.write());
        chunks.push(...RIFFChunk.getParts("lrgn", regionChunks, false, true));

        // This will mostly be false as SF2 -> DLS can't have both global and local regions,
        // So it only has global, hence this check.
        if (this.articulation.length > 0) {
            chunks.push(...this.articulation.write());
        }

        // Write the name
        const inam = RIFFChunk.write("INAM", getStringBytes(this.name, true));
        chunks.push(RIFFChunk.write("INFO", inam, false, true));
        SpessaLog.groupEnd();
        // This one can explode in length (causing a maximum argument crash),
        // So keep as writeParts, not getParts
        return RIFFChunk.writeParts("ins ", chunks, false, true);
    }

    /**
     * Performs the full DLS to SF2 instrument conversion.
     */
    public toSFPreset(soundBank: BasicSoundBank) {
        const preset = new BasicPreset(soundBank);
        preset.name = this.name;
        preset.bankMSB = this.bankMSB;
        preset.bankLSB = this.bankLSB;
        preset.isGMGSDrum = this.isGMGSDrum;
        preset.program = this.program;

        const instrument = new BasicInstrument();
        instrument.name = this.name;
        preset.createZone(instrument);

        // Global articulation
        this.articulation.toSFZone(instrument.globalZone);

        for (const region of this.regions)
            region.toSFZone(instrument, soundBank.samples);

        // Globalize!
        instrument.globalize();

        // Override reverb and chorus with 1000 instead of 200
        // Reverb
        if (
            !instrument.globalZone.modulators.some(
                (m) => m.destination === GeneratorTypes.reverbEffectsSend
            )
        ) {
            instrument.globalZone.addModulators(
                Modulator.copyFrom(DEFAULT_DLS_REVERB)
            );
        }
        // Chorus
        if (
            !instrument.globalZone.modulators.some(
                (m) => m.destination === GeneratorTypes.chorusEffectsSend
            )
        ) {
            instrument.globalZone.addModulators(
                Modulator.copyFrom(DEFAULT_DLS_CHORUS)
            );
        }

        // Remove generators with default values
        instrument.globalZone.generators =
            instrument.globalZone.generators.filter(
                (g) => g.value !== GeneratorLimits[g.type].def
            );

        soundBank.addPresets(preset);
        soundBank.addInstruments(instrument);
    }

    private writeHeader() {
        // Insh: instrument header
        const inshData = new IndexedByteArray(12);
        writeDword(inshData, this.regions.length); // CRegions
        // Bank MSB is in bits 8-14
        let ulBank = ((this.bankMSB & 127) << 8) | (this.bankLSB & 127);
        // Bit 32 means drums
        if (this.isGMGSDrum) {
            ulBank |= 1 << 31;
        }
        writeDword(inshData, ulBank); // UlBank
        writeDword(inshData, this.program & 127); // UlInstrument

        return RIFFChunk.write("insh", inshData);
    }
}
