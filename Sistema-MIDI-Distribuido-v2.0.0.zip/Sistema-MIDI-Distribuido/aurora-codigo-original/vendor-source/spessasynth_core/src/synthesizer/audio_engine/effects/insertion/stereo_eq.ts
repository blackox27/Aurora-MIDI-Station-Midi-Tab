import type { InsertionProcessor } from "../types";
import { InsertionValueConverter } from "./convert";
import {
    type BiquadCoeffs,
    processBiquad,
    ZERO_COEFFS,
    zeroState,
    ZeroStateC
} from "./utils";

/**
 * Stereo-EQ
 * This is a four-band stereo equalizer (low, mid x 2, high).
 * Type: Stereo
 */
export class StereoEQFX implements InsertionProcessor {
    public readonly type = 0x01_00;
    public sendLevelToReverb = 0;
    public sendLevelToChorus = 0;
    public sendLevelToDelay = 0;

    private readonly sampleRate: number;
    private level = 1;
    /**
     * Selects the frequency of the low range (200 Hz/400 Hz).
     * @private
     */
    private lowFreq = 400;
    /**
     * Adjusts the gain of the low frequency.
     * [-12;12]
     * @private
     */
    private lowGain = 5;
    /**
     * Selects the frequency of the high range (4kHz/8kHz).
     * @private
     */
    private hiFreq = 8000;
    /**
     * Adjusts the gain of the high frequency.
     * [-12;12]
     * @private
     */
    private hiGain = -12;
    /**
     * Adjusts the frequency of Mid 1 (mid range1).
     * [200;6300]
     * @private
     */
    private m1Freq = 1600;
    /**
     * This parameter adjusts the width of the area around the M1
     * Freq parameter that will be affected by the Gain setting.
     * Higher values of Q will result in a narrower area being
     * affected.
     * 0.5/1.0/2.0/4.0/9.0
     * @private
     */
    private m1Q = 0.5;
    /**
     * Adjusts the gain for the area specified by the M1 Freq
     * parameter and M1 Q parameter settings.
     * [-12;12]
     * @private
     */
    private m1Gain = 8;
    /**
     * Adjusts the frequency of Mid 2 (mid range2).
     * [200;6300]
     * @private
     */
    private m2Freq = 1000;
    /**
     * This parameter adjusts the width of the area around the M2
     * Freq parameter that will be affected by the Gain setting.
     * Higher values of Q will result in a narrower area being
     * affected.
     * 0.5/1.0/2.0/4.0/9.0
     * @private
     */
    private m2Q = 0.5;
    /**
     * Adjusts the gain for the area specified by the M2 Freq
     * parameter and M2 Q parameter settings.
     * [-12;12]
     * @private
     */
    private m2Gain = -8;

    private readonly lowCoeffs: BiquadCoeffs = { ...ZERO_COEFFS };
    private readonly m1Coeffs: BiquadCoeffs = { ...ZERO_COEFFS };
    private readonly m2Coeffs: BiquadCoeffs = { ...ZERO_COEFFS };
    private readonly hiCoeffs: BiquadCoeffs = { ...ZERO_COEFFS };

    private readonly lowStateL = { ...ZeroStateC };
    private readonly lowStateR = { ...ZeroStateC };
    private readonly m1StateL = { ...ZeroStateC };
    private readonly m1StateR = { ...ZeroStateC };
    private readonly m2StateL = { ...ZeroStateC };
    private readonly m2StateR = { ...ZeroStateC };
    private readonly hiStateL = { ...ZeroStateC };
    private readonly hiStateR = { ...ZeroStateC };

    public constructor(sampleRate: number) {
        this.sampleRate = sampleRate;
        this.reset();
        this.updateCoefficients();
    }

    public reset() {
        this.level = 1;
        this.lowFreq = 400;
        this.lowGain = 5;
        this.hiGain = -12;
        this.hiFreq = 8000;
        this.m1Freq = 1600;
        this.m1Q = 0.5;
        this.m1Gain = 8;
        this.m2Freq = 1000;
        this.m2Q = 0.5;
        this.m2Gain = -8;

        // Reset states
        zeroState(this.lowStateL);
        zeroState(this.lowStateR);
        zeroState(this.m1StateL);
        zeroState(this.m1StateR);
        zeroState(this.m2StateL);
        zeroState(this.m2StateR);
        zeroState(this.hiStateL);
        zeroState(this.hiStateR);
        this.updateCoefficients();
    }

    public setParameter(parameter: number, value: number) {
        switch (parameter) {
            default: {
                break;
            }

            case 0x03: {
                this.lowFreq = value === 1 ? 400 : 200;
                break;
            }

            case 0x04: {
                this.lowGain = value - 64;
                break;
            }

            case 0x05: {
                this.hiFreq = value === 1 ? 8000 : 4000;
                break;
            }

            case 0x06: {
                this.hiGain = value - 64;
                break;
            }

            case 0x07: {
                this.m1Freq = InsertionValueConverter.eqFreq(value);
                break;
            }

            case 0x08: {
                this.m1Q = [0.5, 1, 2, 4, 9][value] || 1;
                break;
            }

            case 0x09: {
                this.m1Gain = value - 64;
                break;
            }

            case 0x0a: {
                this.m2Freq = InsertionValueConverter.eqFreq(value);
                break;
            }

            case 0x0b: {
                this.m2Q = [0.5, 1, 2, 4, 9][value] || 1;
                break;
            }

            case 0x0c: {
                this.m2Gain = value - 64;
                break;
            }

            case 0x16: {
                this.level = value / 127;
                break;
            }
        }
        this.updateCoefficients();
    }

    public process(
        inputLeft: Float32Array,
        inputRight: Float32Array,
        outputLeft: Float32Array,
        outputRight: Float32Array,
        outputReverb: Float32Array,
        outputChorus: Float32Array,
        outputDelay: Float32Array,
        startIndex: number,
        sampleCount: number
    ) {
        const {
            level,
            sendLevelToChorus,
            sendLevelToDelay,
            sendLevelToReverb,
            lowCoeffs,
            lowStateL,
            lowStateR,
            m1Coeffs,
            m1StateL,
            m1StateR,
            m2StateL,
            m2StateR,
            m2Coeffs,
            hiCoeffs,
            hiStateL,
            hiStateR
        } = this;
        for (let i = 0; i < sampleCount; i++) {
            let sL = inputLeft[i];
            let sR = inputRight[i];

            // Low -> m1 -> m2 -> hi
            sL = processBiquad(sL, lowCoeffs, lowStateL);
            sR = processBiquad(sR, lowCoeffs, lowStateR);

            sL = processBiquad(sL, m1Coeffs, m1StateL);
            sR = processBiquad(sR, m1Coeffs, m1StateR);

            sL = processBiquad(sL, m2Coeffs, m2StateL);
            sR = processBiquad(sR, m2Coeffs, m2StateR);

            sL = processBiquad(sL, hiCoeffs, hiStateL);
            sR = processBiquad(sR, hiCoeffs, hiStateR);

            // Mix
            const idx = startIndex + i;
            outputLeft[idx] += sL * level;
            outputRight[idx] += sR * level;
            // Sends (index 0)
            const mono = 0.5 * (sL + sR);
            outputReverb[i] += mono * sendLevelToReverb;
            outputChorus[i] += mono * sendLevelToChorus;
            outputDelay[i] += mono * sendLevelToDelay;
        }
    }

    private updateCoefficients() {
        // Dividing low and hi gain by 2 seems to improve accuracy to SCVA
        computeLowShelfCoeffs(
            this.lowCoeffs,
            this.lowFreq,
            this.lowGain / 2,
            this.sampleRate
        );

        computePeakingEQCoeffs(
            this.m1Coeffs,
            this.m1Freq,
            this.m1Gain,
            this.m1Q,
            this.sampleRate
        );

        computePeakingEQCoeffs(
            this.m2Coeffs,
            this.m2Freq,
            this.m2Gain,
            this.m2Q,
            this.sampleRate
        );

        computeHighShelfCoeffs(
            this.hiCoeffs,
            this.hiFreq,
            this.hiGain / 2,
            this.sampleRate
        );
    }
}

/**
 * Robert Bristow-Johnson cookbook formulas
 * (https://webaudio.github.io/Audio-EQ-Cookbook/audio-eq-cookbook.html)
 *
 * S - a "shelf slope" parameter (for shelving EQ only).
 * When S = 1, the shelf slope is as steep as it can be and remain monotonically increasing or decreasing gain with frequency.
 * The shelf slope, in dB/octave,
 * remains proportional to S for all other values for a fixed  f0/Fs and dB gain.
 */
const SHELF_SLOPE = 1;

function computePeakingEQCoeffs(
    coeffs: BiquadCoeffs,
    freq: number,
    gainDB: number,
    Q: number,
    sampleRate: number
) {
    const A = Math.pow(10, gainDB / 40);
    const w0 = (2 * Math.PI * freq) / sampleRate;
    const cosw0 = Math.cos(w0);
    const sinw0 = Math.sin(w0);
    const alpha = sinw0 / (2 * Q);

    const b0 = 1 + alpha * A;
    const b1 = -2 * cosw0;
    const b2 = 1 - alpha * A;
    const a0 = 1 + alpha / A;
    const a1 = -2 * cosw0;
    const a2 = 1 - alpha / A;

    coeffs.a0 = 1;
    coeffs.a1 = a1 / a0;
    coeffs.a2 = a2 / a0;
    coeffs.b0 = b0 / a0;
    coeffs.b1 = b1 / a0;
    coeffs.b2 = b2 / a0;
}

function computeLowShelfCoeffs(
    coeffs: BiquadCoeffs,
    freq: number,
    gainDB: number,
    sampleRate: number
) {
    const A = Math.pow(10, gainDB / 40);
    const w0 = (2 * Math.PI * freq) / sampleRate;
    const cosw0 = Math.cos(w0);
    const sinw0 = Math.sin(w0);
    const alpha =
        (sinw0 / 2) * Math.sqrt((A + 1 / A) * (1 / SHELF_SLOPE - 1) + 2);

    const b0 = A * (A + 1 - (A - 1) * cosw0 + 2 * Math.sqrt(A) * alpha);
    const b1 = 2 * A * (A - 1 - (A + 1) * cosw0);
    const b2 = A * (A + 1 - (A - 1) * cosw0 - 2 * Math.sqrt(A) * alpha);
    const a0 = A + 1 + (A - 1) * cosw0 + 2 * Math.sqrt(A) * alpha;
    const a1 = -2 * (A - 1 + (A + 1) * cosw0);
    const a2 = A + 1 + (A - 1) * cosw0 - 2 * Math.sqrt(A) * alpha;

    coeffs.a0 = 1;
    coeffs.a1 = a1 / a0;
    coeffs.a2 = a2 / a0;
    coeffs.b0 = b0 / a0;
    coeffs.b1 = b1 / a0;
    coeffs.b2 = b2 / a0;
}

function computeHighShelfCoeffs(
    coeffs: BiquadCoeffs,
    freq: number,
    gainDB: number,
    sampleRate: number
) {
    const A = Math.pow(10, gainDB / 40);
    const w0 = (2 * Math.PI * freq) / sampleRate;
    const cosw0 = Math.cos(w0);
    const sinw0 = Math.sin(w0);
    const alpha =
        (sinw0 / 2) * Math.sqrt((A + 1 / A) * (1 / SHELF_SLOPE - 1) + 2);

    const b0 = A * (A + 1 + (A - 1) * cosw0 + 2 * Math.sqrt(A) * alpha);
    const b1 = -2 * A * (A - 1 + (A + 1) * cosw0);
    const b2 = A * (A + 1 + (A - 1) * cosw0 - 2 * Math.sqrt(A) * alpha);
    const a0 = A + 1 - (A - 1) * cosw0 + 2 * Math.sqrt(A) * alpha;
    const a1 = 2 * (A - 1 - (A + 1) * cosw0);
    const a2 = A + 1 - (A - 1) * cosw0 - 2 * Math.sqrt(A) * alpha;

    coeffs.a0 = 1;
    coeffs.a1 = a1 / a0;
    coeffs.a2 = a2 / a0;
    coeffs.b0 = b0 / a0;
    coeffs.b1 = b1 / a0;
    coeffs.b2 = b2 / a0;
}
