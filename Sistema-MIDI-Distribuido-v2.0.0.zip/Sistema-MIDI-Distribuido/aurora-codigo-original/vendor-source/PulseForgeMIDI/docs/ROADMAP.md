# Roteiro sugerido

## 1.0 — editor completo

- Gravação MIDI com contagem, metrônomo, punch in/out e overdub.
- Loop por região, marcadores e snapping adaptativo.
- Um grafo de instrumentos/efeitos por pista e mixer com medidores.
- Scanner persistente de plug-ins com quarentena para plug-ins que falham.
- Mapas de tempo e fórmula de compasso.
- Preferências de dispositivo, buffer e roteamento MIDI.
- Autosave e recuperação após falha.

## 1.1 — expressão e composição

- MPE e expressão por nota.
- Curvas Bézier para CC, pitch bend e automação de parâmetros VST.
- Escalas, acordes, ghost notes e humanização.
- Articulações, ligaduras e exportação/importação MusicXML.

## 1.2 — produção e distribuição

- Congelamento de pistas e render paralelo seguro.
- Instaladores assinados para Windows/macOS e pacotes Linux.
- Testes de integração MIDI/áudio e fuzzing dos importadores.
- Acessibilidade completa por teclado e leitores de tela.
