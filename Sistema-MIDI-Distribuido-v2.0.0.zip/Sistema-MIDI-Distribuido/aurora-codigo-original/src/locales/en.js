/* English catalog; Portuguese source keys provide the PT-BR fallback. */
globalThis.AURORA_EN = {
  "RIFF MIDI: bancos embutidos e metadados externos ao SMF não são importados.":
    "RIFF MIDI: embedded sound banks and metadata outside the SMF are not imported.",
  Silenciar: "Mute",
  "(cópia)": "(copy)",
  "0 notas": "0 notes",
  "0/16 bancos no projeto": "0/16 sound banks in project",
  "1/8 trio": "1/8 triplet",
  "A colagem excede o limite do projeto.":
    "Pasting would exceed the project limit.",
  "A pista referencia um banco de sons ausente.":
    "The track refers to a missing sound bank.",
  "A posição começa em 0. Uma mudança por linha. Exemplo: 16, 90 ou 16, 3/4.":
    "Positions start at 0. One change per line. Example: 16, 90 or 16, 3/4.",
  "A transposição ultrapassa o intervalo MIDI.":
    "Transposition would exceed the MIDI range.",
  "Acompanhar cursor durante a reprodução": "Follow the cursor during playback",
  "Adicionar SF2 / SF3 / DLS": "Add SF2 / SF3 / DLS",
  "Adicionar notas à pista ativa do Aurora.":
    "Add notes to the active Aurora track.",
  "Adicionar pista": "Add track",
  "Adicione um SoundFont": "Add a SoundFont",
  Ajuda: "Help",
  "Ajustar visão": "Fit notes",
  "Ajustar visão às notas": "Fit the view to the notes",
  Ajustes: "Settings",
  "Andamento inválido.": "Invalid tempo.",
  "Andamento nulo.": "Zero tempo.",
  "Andamento: tempo de semínima, BPM": "Tempo: quarter-note position, BPM",
  "Andamentos e compassos": "Tempo and time signatures",
  "Apagar · E": "Erase · E",
  "Aplica pequenas variações aleatórias de início e intensidade. Preserva a duração e os limites do projeto.":
    "Apply small random changes to timing and velocity. Note durations and project boundaries are preserved.",
  "Aplica às notas selecionadas; sem seleção, à pista inteira.":
    "Apply to selected notes, or the entire track if nothing is selected.",
  "Aplicar este banco a todas as pistas": "Apply this bank to all tracks",
  "Aplicar mapas": "Apply maps",
  "Aplicar às notas": "Apply to notes",
  "Arquivo MIDI inválido ou maior que 40 MB.":
    "Invalid MIDI file or larger than 40 MB.",
  "Arquivo MIDI truncado.": "Truncated MIDI file.",
  "Arquivo de áudio ausente. Recarregue-o ou abra o projeto portátil.":
    "Audio file missing. Load it again or open the portable project.",
  "Arquivo maior que 260 MB.": "File larger than 260 MB.",
  "Arraste um arquivo MIDI ou projeto Aurora.":
    "Drop a MIDI file or an Aurora project.",
  "As notas e automações desta pista serão removidas. Você pode desfazer.":
    "The notes and automation in this track will be removed. You can undo this action.",
  "Aurora · banco sintético de demonstração":
    "Aurora · synthetic demo sound bank",
  "Automação inválida.": "Invalid automation.",
  "BPM inicial alterado. Os outros andamentos foram preservados.":
    "Initial BPM changed. Other tempo changes were preserved.",
  "Baixo suave": "Soft bass",
  "Baixo triangular": "Triangle bass",
  "Banco adicionado ·": "Sound bank added ·",
  "Banco de demonstração": "Demo sound bank",
  "Banco de sons ausente:": "Missing sound bank:",
  "Banco desta pista": "Track sound bank",
  "Banco sem identificação.": "Sound bank has no identifier.",
  "Bateria ·": "Drums ·",
  "Cabeçalho MIDI inválido.": "Invalid MIDI header.",
  "Cada banco deve ter até 128 MB.":
    "Each sound bank must be 128 MB or smaller.",
  "Canal MIDI": "MIDI channel",
  "Canal de automação": "Automation lane",
  Cancelar: "Cancel",
  "Carregamento do banco cancelado.": "Sound bank loading cancelled.",
  "Carregando presets…": "Loading presets…",
  "Carregue o banco de sons desta pista.": "Load this track's sound bank.",
  "Carregue um": "Load an",
  "Carregue um banco SF2/SF3/DLS.": "Load an SF2/SF3/DLS sound bank.",
  "Chunk de pista MIDI inválido.": "Invalid MIDI track chunk.",
  "Clique na pauta para inserir notas. Clique numa nota para selecioná-la; Delete para apagar. Acidentes e pausas complexas: use o piano roll.":
    "Click the staff to add notes. Click a note to select it; press Delete to remove it. Use the piano roll for complex accidentals and rests.",
  "Clique ou arraste para editar velocity ou automação":
    "Click or drag to edit velocity or automation",
  "Codificando MP3…": "Encoding MP3…",
  Colcheia: "Eighth note",
  "Compasso inválido.": "Invalid time signature.",
  "Compasso: tempo de semínima, numerador/denominador":
    "Time signature: quarter-note position, numerator/denominator",
  Compassos: "Bars",
  "Conectar MIDI": "Connect MIDI",
  "Contêiner RIFF MIDI inválido.": "Invalid RIFF MIDI container.",
  "Contêiner RIFF MIDI sem dados SMF.": "RIFF MIDI container has no SMF data.",
  "Contêiner RIFF MIDI truncado.": "Truncated RIFF MIDI container.",
  "Criar curva": "Create curve",
  "Criar projeto vazio": "Create empty project",
  "Curva de glide": "Glide curve",
  "Dado MIDI fora da faixa.": "MIDI data out of range.",
  "Delta MIDI inválido.": "Invalid MIDI delta time.",
  "Desenhar · B": "Draw · B",
  "Desfazer · Ctrl+Z": "Undo · Ctrl+Z",
  Deslocamento: "Offset",
  "Dividir nota · C": "Split note · C",
  "Divisão SMPTE não suportada; use MIDI PPQ.":
    "SMPTE time division is not supported; use PPQ MIDI.",
  Duplicar: "Duplicate",
  "Duplicar pista": "Duplicate track",
  "Duplicar · Ctrl+D": "Duplicate · Ctrl+D",
  Duração: "Duration",
  "EDITOR DE NOTAS": "NOTE EDITOR",
  "Editar andamentos e compassos": "Edit tempos and time signatures",
  "Escolha o banco desta pista": "Choose this track's sound bank",
  "Escolha um banco de sons para a pista": "Choose a sound bank for track",
  "Escolha um banco de sons para esta pista.":
    "Choose a sound bank for this track.",
  "Escolha um banco nesta pista primeiro.":
    "Choose a sound bank for this track first.",
  Espaço: "Space",
  "Esta pista não contém notas.": "This track has no notes.",
  "Este banco está em uso. Troque o banco ou o timbre das pistas que o utilizam antes de removê-lo.":
    "This bank is in use. Change the bank or instrument on the tracks that use it before removing it.",
  "Este navegador não disponibilizou AudioWorklet. Abra o HTML em Chrome/Edge atualizado ou use a versão online.":
    "AudioWorklet is unavailable in this browser. Open the HTML in an updated Chrome or Edge browser.",
  "Evento MIDI inválido.": "Invalid MIDI event.",
  "Evento MIDI muito distante.": "MIDI event delta is too large.",
  "Evento de andamento inválido.": "Invalid tempo event.",
  "Evento desconhecido": "Unknown event",
  Excluir: "Delete",
  "Excluir notas selecionadas": "Delete selected notes",
  "Excluir pista": "Delete track",
  "Excluir pista?": "Delete track?",
  "Exportar música": "Export music",
  "Exportar ↗": "Export ↗",
  "Exportação cancelada.": "Export cancelled.",
  "Exportação concluída.": "Export complete.",
  "Exporte até 10 minutos por vez.": "Export up to 10 minutes at a time.",
  "Expressão · CC 11": "Expression · CC 11",
  "Falha no render de SoundFont": "SoundFont rendering failed",
  Fechar: "Close",
  Ferramentas: "Tools",
  "Ferramentas de edição": "Editing tools",
  "Fim de pista MIDI inválido.": "Invalid MIDI end-of-track event.",
  "Formato 2 contém sequências independentes. Converta para formato 0 ou 1.":
    "Format 2 contains independent sequences. Convert to format 0 or 1.",
  "Força (%)": "Strength (%)",
  "Força parcial mantém parte da variação original. Swing desloca as subdivisões ímpares.":
    "Partial strength preserves some original variation. Swing shifts odd subdivisions.",
  "Força, swing e duração": "Strength, swing and duration",
  "Fórmula de compasso inválida.": "Invalid time signature.",
  "Glide por pitch bend": "Pitch bend glide",
  Grade: "Grid",
  "Gravar entrada MIDI ou teclado": "Record MIDI input or keyboard",
  "Gravação armada · toque durante a reprodução":
    "Recording armed · play during playback",
  "Gravação desarmada": "Recording disarmed",
  "Humanizar notas": "Humanize notes",
  "Humanização aplicada a {count} nota(s).":
    "Humanization applied to {count} note(s).",
  "Humanização e limpeza afetam a seleção ou, sem seleção, toda a pista. Todas as operações podem ser desfeitas.":
    "Humanization and cleanup affect the selection, or the entire track if nothing is selected. All operations can be undone.",
  INSTRUMENTO: "INSTRUMENT",
  Imprimir: "Print",
  "IndexedDB indisponível": "IndexedDB unavailable",
  Instrumento: "Instrument",
  "Interromper todas as notas · Esc": "Stop all notes · Esc",
  "Lead analógico": "Analog lead",
  "Limite de 16 bancos. Remova um banco sem uso para adicionar outro.":
    "Limit of 16 sound banks. Remove an unused bank to add another.",
  "Limite de 16 pistas.": "Limit of 16 tracks.",
  "Limite de 4096 tempos.": "Limit of 4096 quarter-note beats.",
  "Limpar CC": "Clear CC",
  Livre: "Free",
  "MIDI conectado ·": "MIDI connected ·",
  "MIDI exportado": "MIDI exported",
  "MIDI formato 0 deve conter uma única pista.":
    "MIDI format 0 must contain exactly one track.",
  "MIDI importado": "Imported MIDI",
  "MIDI inclui todas as pistas. WAV e MP3 respeitam mute, solo, samples, SoundFont e automações.":
    "MIDI includes all tracks. WAV and MP3 respect mute, solo, samples, SoundFonts and automation.",
  "Mantenha pelo menos uma pista.": "Keep at least one track.",
  "Manual e limites": "Manual and limitations",
  "Mapa de andamento": "Tempo map",
  "Mapa de andamento inválido.": "Invalid tempo map.",
  "Mapa de andamento muito grande.": "Tempo map is too large.",
  "Mapa de compassos": "Time signature map",
  "Mapa de compassos inválido.": "Invalid time signature map.",
  "Mapa de compassos muito grande.": "Time signature map is too large.",
  "Mensagem de sistema inválida para SMF.": "Invalid system message in SMF.",
  "Mensagens SysEx foram omitidas.": "SysEx messages were omitted.",
  "Modulação · CC 1": "Modulation · CC 1",
  "Mova ou apague os eventos finais antes de reduzir.":
    "Move or delete events at the end before shortening the song.",
  "Muitos eventos MIDI.": "Too many MIDI events.",
  Mínima: "Half note",
  "Nenhuma nota selecionada": "No notes selected",
  Nome: "Name",
  "Nome da pista": "Track name",
  "Nome do projeto": "Project name",
  "Nota base do sample": "Sample root note",
  "Nota inválida ou fora da duração do projeto.":
    "Invalid note or outside the project duration.",
  "Notas inválidas.": "Invalid notes.",
  "Notas sem Note Off foram encerradas no fim da pista.":
    "Notes without Note Off were closed at the end of their track.",
  Novo: "New",
  "Novo projeto": "New project",
  "Não foi possível restaurar o projeto:": "Could not restore the project:",
  "Número de pistas inválido.": "Invalid track count.",
  "O MIDI contém mais de 16 combinações de pista/canal. Reduza-as antes de importar.":
    "The MIDI contains more than 16 track/channel combinations. Reduce them before importing.",
  "O MIDI excede 4096 tempos de semínima.":
    "The MIDI exceeds 4096 quarter-note beats.",
  "O MIDI excede um milhão de eventos.": "The MIDI exceeds one million events.",
  "O banco demorou demais para carregar.":
    "The sound bank took too long to load.",
  "O banco foi removido durante o carregamento.":
    "The sound bank was removed while loading.",
  "O banco não contém instrumentos.": "The sound bank contains no instruments.",
  "O limite é de 4096 tempos de semínima.":
    "The limit is 4096 quarter-note beats.",
  "O navegador não guardou o áudio. Salve um projeto portátil para preservar os arquivos.":
    "The browser did not save the audio. Save a portable project to preserve the files.",
  "O projeto aceita até 16 bancos de sons.":
    "The project supports up to 16 sound banks.",
  "O projeto deve ter de 1 a 16 pistas.":
    "The project must contain 1 to 16 tracks.",
  "O projeto foi editado durante a importação. Abra o arquivo novamente.":
    "The project was edited during import. Open the file again.",
  "O projeto mudou durante o carregamento.":
    "The project changed while loading.",
  "O projeto não contém todos os samples.":
    "The project does not contain all samples.",
  "O sample deve ter até 50 MB.": "The sample must be 50 MB or smaller.",
  "Os salvamentos encontrados estão inválidos. Abra sua cópia portátil.":
    "The saved projects are invalid. Open your portable copy.",
  PISTAS: "TRACKS",
  "Pan · CC 10": "Pan · CC 10",
  "Parar e voltar ao início": "Stop and return to the start",
  Partitura: "Score",
  "Pauta dupla": "Grand staff",
  Percussão: "Percussion",
  "Piano elétrico": "Electric piano",
  "Piano roll: clique para criar notas, arraste para mover, arraste a borda direita para alterar a duração":
    "Piano roll: click to add notes, drag to move, drag the right edge to resize",
  "Pista 1": "Track 1",
  "Pista inválida ou muito grande.": "Invalid track or track too large.",
  "Pista inválida.": "Invalid track.",
  "Pistas com o mesmo canal compartilham controles na saída MIDI.":
    "Tracks with the same channel share controls on MIDI output.",
  "Pitch bend afeta todas as notas do canal. A curva volta ao centro no fim de cada nota.":
    "Pitch bend affects all notes on the channel. The curve returns to the center at the end of each note.",
  "Pitch bend · ±2 semitons": "Pitch bend · ±2 semitones",
  "Preparando instrumentos…": "Preparing instruments…",
  "Projeto PulseForge inválido.": "Invalid PulseForge project.",
  "Projeto aberto. Os áudios são restaurados ao tocar.":
    "Project opened. Audio assets are restored on playback.",
  "Projeto excede 180 MB de áudio.": "Project exceeds 180 MB of audio.",
  "Projeto portátil inválido.": "Invalid portable project.",
  "Projeto portátil limitado a 180 MB de áudio.":
    "Portable projects are limited to 180 MB of audio.",
  "Projeto portátil salvo com os arquivos de áudio.":
    "Portable project saved with audio assets.",
  "Pronto para compor": "Ready to compose",
  "Próxima página": "Next page",
  "Página anterior": "Previous page",
  Pânico: "Panic",
  Quantizar: "Quantize",
  "Quantizar também o fim das notas": "Also quantize note ends",
  Quantização: "Quantization",
  "Quantização aplicada": "Quantization applied",
  "Recarregue o banco de sons desta pista.":
    "Load this track's sound bank again.",
  "Recarregue o sample da pista": "Load the sample again for track",
  "Recarregue os bancos de sons antes de exportar.":
    "Load the sound banks again before exporting.",
  "Refazer · Ctrl+Shift+Z": "Redo · Ctrl+Shift+Z",
  "Referência de banco de sons inválida ou duplicada.":
    "Invalid or duplicate sound bank reference.",
  "Referência de sample inválida.": "Invalid sample reference.",
  "Remover banco sem uso": "Remove unused sound bank",
  "Remover notas duplicadas": "Remove duplicate notes",
  "Renderizando SoundFont…": "Rendering SoundFont…",
  "Renderizando sintetizadores e samples…":
    "Rendering synthesizers and samples…",
  "Repetir projeto": "Loop project",
  "Reproduzir · Espaço": "Play · Space",
  Reproduzindo: "Playing",
  "Running status inválido.": "Invalid running status.",
  "Salvamento automático indisponível. Salve um projeto portátil.":
    "Autosave unavailable. Save a portable project.",
  "Salvar nome": "Save name",
  "Salvar projeto": "Save project",
  "Salve uma cópia portátil para guardar o trabalho atual. A criação também pode ser desfeita.":
    "Save a portable copy to keep your current work. Creating a new project can also be undone.",
  "Sample ausente na pista": "Sample missing on track",
  "Sample carregado": "Loaded sample",
  "Sample carregado e guardado no projeto.":
    "Sample loaded and saved in the project.",
  "Saída MIDI": "MIDI output",
  "Saída MIDI desconectada.": "MIDI output disconnected.",
  "Saída MIDI desconectada:": "MIDI output disconnected:",
  "Saída externa selecionada": "External output selected",
  "Saída interna selecionada": "Internal output selected",
  "Saída: sintetizador interno": "Output: internal synthesizer",
  Seguir: "Follow",
  Selecionar: "Select",
  "Selecionar · V": "Select · V",
  "Selecione as notas para criar o glide.": "Select notes to create the glide.",
  "Selecione notas e use o campo Velocity.":
    "Select notes and use the Velocity field.",
  "Selecione um banco": "Select a sound bank",
  "Selecione um preset": "Select a preset",
  "Selecione uma grade antes de quantizar.": "Select a grid before quantizing.",
  "Sem título": "Untitled",
  Semibreve: "Whole note",
  Semicolcheia: "Sixteenth note",
  Semitons: "Semitones",
  Semínima: "Quarter note",
  "Seno suave": "Soft sine",
  "Só remove bancos sem uso nas pistas":
    "Only removes sound banks unused by tracks",
  "Teclado musical:": "Musical keyboard:",
  "Textos, letras e metadados não musicais não entram no projeto.":
    "Text, lyrics and non-musical metadata are not included in the project.",
  "Textura analógica": "Analog texture",
  Timbre: "Instrument",
  "Todas as notas foram interrompidas.": "All notes stopped.",
  Transpor: "Transpose",
  "Transpor notas": "Transpose notes",
  "Use posição, BPM em cada linha.": "Use position, BPM on each line.",
  "Use posição, numerador/denominador.": "Use position, numerator/denominator.",
  "Use um arquivo Standard MIDI (.mid).": "Use a Standard MIDI file (.mid).",
  "Variação de início (tempos)": "Timing variation (beats)",
  "Variação de velocity": "Velocity variation",
  "Variação inválida.": "Invalid variation.",
  "Volume da pista": "Track volume",
  "Volume · CC 7": "Volume · CC 7",
  "WAV 44,1 kHz": "WAV 44.1 kHz",
  "WAV, MP3 ou OGG · nota base C4": "WAV, MP3 or OGG · root note C4",
  "Web MIDI não disponível. Use Chrome ou Edge e abra por HTTPS ou localhost.":
    "Web MIDI is unavailable. Use Chrome or Edge over HTTPS or localhost.",
  "entrada(s)": "input(s)",
  "limite de 128 MB por banco": "128 MB limit per sound bank",
  "nota(s) selecionada(s)": "note(s) selected",
  "notas copiadas": "notes copied",
  "presets. As outras pistas mantêm seus bancos.":
    "presets. Other tracks keep their sound banks.",
  semitons: "semitones",
  tempos: "beats",
  "{count} nota(s) duplicada(s) removida(s).":
    "{count} duplicate note(s) removed.",
  "· mapa": "· map",
  "Áudio estéreo com 4 segundos de cauda.":
    "Stereo audio with a 4-second tail.",
  "Áudio inválido no projeto.": "Invalid audio in project.",
  "Áudio pronto": "Audio ready",
  "Órbita — estudo em dó": "Orbit — study in C",
  "↥ Abrir": "↥ Open",
  "◈ Carregando projeto local…": "◈ Loading local project…",
  "◈ Projeto salvo neste navegador": "◈ Project saved in this browser",
  "◈ Salvamento automático no navegador": "◈ Browser autosave",
  "◈ Salve uma cópia portátil": "◈ Save a portable copy",
  "✎ Clique para criar · Arraste para mover · Borda para duração · Shift para multisseleção":
    "✎ Click to add · Drag to move · Edge to resize · Shift for multiple selection",
  "＋ Carregar sample": "＋ Load sample",
  NOTA: "NOTE",
  "Baixar aplicativo HTML": "Download HTML app",
  "toca/pausa;": "plays/pauses;",
  "desenha/seleciona/apaga/divide.": "draws/selects/erases/splits.",
  "alterna seleção. Ctrl/Cmd + A/C/X/V/D/Z seleciona, copia, recorta, cola, duplica e desfaz. A colagem começa no cursor da régua.":
    "toggles selection. Ctrl/Cmd + A/C/X/V/D/Z selects, copies, cuts, pastes, duplicates and undoes. Pasting starts at the ruler cursor.",
  "Ctrl + roda: zoom horizontal ancorado no cursor. Alt + roda: altura das notas. Shift + roda: navegar no tempo. Nos controles de automação, botão direito apaga pontos.":
    "Ctrl + wheel: horizontal zoom anchored at the cursor. Alt + wheel: note height. Shift + wheel: move along the timeline. Right-click automation points to remove them.",
  "A W S X D F T G Y H U J K toca C4 a C5 (X = D♯). Arme ● e toque durante a reprodução para gravar. A edição pausa o transporte para evitar eventos antigos.":
    "A W S X D F T G Y H U J K plays C4 to C5 (X = D♯). Arm ● and play during playback to record. Editing pauses playback to prevent stale events.",
  ", escolha SpessaSynth na pista e selecione um preset. Adicione vários arquivos e escolha o banco e o preset de cada pista. Os bancos tocam juntos e também entram na exportação de áudio. Salvar projeto gera um":
    ", choose SpessaSynth on the track and select a preset. Add multiple files and choose a bank and preset for each track. Sound banks play together and are included in audio export. Save project creates a",
  ".aurora portátil": "portable .aurora file",
  "com samples e todos os bancos de sons incluídos.":
    "with samples and all sound banks included.",
  "VST3/AU continuam exigindo um host instalado, conectado por MIDI virtual. A partitura é básica; a impressão cobre a página visível. SysEx e letras não são preservados pelo importador.":
    "VST3/AU require an installed host connected through virtual MIDI. Score notation is basic; printing covers the visible page. SysEx and lyrics are not preserved on import.",
  "VSTi: use uma porta MIDI virtual conectada ao seu host externo. O áudio exportado usa os instrumentos internos.":
    "VSTi: use a virtual MIDI port connected to your external host. Exported audio uses internal instruments.",
  "Base: PulseForge MIDI (MIT); SpessaSynth core 4.3.22 e lib 4.3.14 (Apache-2.0); MP3: lamejs 1.2.1/LAME (LGPL). Licenças e alterações estão no download.":
    "Based on PulseForge MIDI (MIT); SpessaSynth core 4.3.22 and lib 4.3.14 (Apache-2.0); MP3: lamejs 1.2.1/LAME (LGPL). Licenses and changes are included in the download.",
  "{v0} notas · canal {v1}": "{v0} notes · channel {v1}",
  "{v0}/16 bancos no projeto": "{v0}/16 sound banks in project",
  "{v0} notas · {v1} compassos": "{v0} notes · {v1} bars",
  "Pauta dupla · página {v0}/{v1}": "Grand staff · page {v0}/{v1}",
  "{v0} banco(s) adicionado(s).": "{v0} sound bank(s) added.",
  "{v0} bancos adicionados. Escolha um banco em cada pista.":
    "{v0} sound banks added. Choose a sound bank on each track.",
};
